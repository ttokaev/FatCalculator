create unique index PRIMARY_KEY_27
    on TAPE (MEASUREMENT_ID);

